# courses
Here, I include all the required resources for the courses I teach, either online or in academia
